export interface Student {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phone?: string;
  group: string;
  course: number;
  specialty: string;
  avatar?: string;
  createdAt: string;
  role: 'student';
}

export interface Teacher {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phone?: string;
  subject: string;
  department: string;
  avatar?: string;
  createdAt: string;
  role: 'teacher';
}

export type User = Student | Teacher;

export interface ScheduleItem {
  id: string;
  group: string;
  day: string;
  subject: string;
  teacher: string;
  room: string;
  startTime: string;
  endTime: string;
  type: 'lecture' | 'practice' | 'lab';
}

export interface Grade {
  id: string;
  studentId: string;
  studentName: string;
  studentGroup: string;
  subject: string;
  teacherId: string;
  teacherName: string;
  type: 'exam' | 'test' | 'homework' | 'project' | 'quiz';
  score: number;
  maxScore: number;
  date: string;
  semester: string;
  comment?: string;
}

export interface Attendance {
  id: string;
  studentId: string;
  subject: string;
  date: string;
  status: 'present' | 'absent' | 'late' | 'excused';
}

export interface NewsItem {
  id: string;
  title: string;
  content: string;
  author: string;
  date: string;
  category: 'general' | 'academic' | 'event' | 'urgent';
  image?: string;
}

export interface AppState {
  currentUser: User | null;
  isAuthenticated: boolean;
}
