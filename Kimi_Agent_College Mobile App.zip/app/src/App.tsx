import { useState, useEffect } from 'react';
import { 
  Home, 
  Calendar, 
  BookOpen, 
  User as UserIcon, 
  Bell, 
  LogOut, 
  Menu,
  X,
  GraduationCap,
  Clock,
  MapPin,
  Star,
  Users,
  Search,
  Plus,
  Edit3,
  Trash2,
  Save,
  Award,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import type { Student, Teacher, User, Grade, NewsItem } from '@/types';
import { groups, getScheduleByGroupAndDay } from '@/data/schedule';
import './App.css';

type View = 'login' | 'register' | 'dashboard' | 'schedule' | 'grades' | 'profile' | 'news' | 'teacher-grades' | 'students';
type UserRole = 'student' | 'teacher';

// Subjects list for teachers
const subjectsList = [
  'Математика',
  'Физика',
  'Ағылшын тілі',
  'Программалау',
  'Банктегі есеп',
  'Банк операциялары',
  'Банктік қадағалау және аудит',
  'Экономикалық талдау және ҚЕТ',
  'Компьютерлік желілер',
  'Микроконтроллерді бағдарламалау',
  'Мобильді қосымшаларды әзірлеу',
  'Жоғары деңгейлі тілдерде бағдарламалау',
  'Аудит',
  'Қаржылық есеп',
  'Менеджмент',
  'Маркетинг',
  'Құқық',
  'Криминалистика',
];

const departmentsList = [
  'Ақпараттық технологиялар',
  'Экономика және қаржы',
  'Менеджмент',
  'Құқық',
  'Банк ісі',
];

// Mock news
const mockNews: NewsItem[] = [
  { 
    id: '1', 
    title: 'Қысқы емтихан сессиясы басталды', 
    content: 'Құрметті студенттер! 2026 жылдың қысқы емтихан сессиясы 15 қаңтардан басталады.', 
    author: 'Оқу ісі жөніндегі проректор', 
    date: '2026-01-10', 
    category: 'academic' 
  },
  { 
    id: '2', 
    title: 'Студенттер күніне арналған мерекелік іс-шара', 
    content: '25 қаңтарда студенттер күніне орай колледжде концерт өтеді!', 
    author: 'Студенттер кеңесі', 
    date: '2026-01-20', 
    category: 'event' 
  },
];

function App() {
  const [currentView, setCurrentView] = useState<View>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string>('');

  // Load data from localStorage
  useEffect(() => {
    const savedUsers = localStorage.getItem('college_users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    }
    const savedGrades = localStorage.getItem('college_grades');
    if (savedGrades) {
      setGrades(JSON.parse(savedGrades));
    }
    const savedUser = localStorage.getItem('college_current_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      if (user.role === 'student') {
        setSelectedGroup(user.group);
      }
      setCurrentView('dashboard');
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem('college_users', JSON.stringify(users));
    }
  }, [users]);

  useEffect(() => {
    localStorage.setItem('college_grades', JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('college_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('college_current_user');
    }
  }, [currentUser]);

  const handleLogin = (email: string, password: string) => {
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      setCurrentUser(user);
      if (user.role === 'student') {
        setSelectedGroup(user.group);
      }
      setCurrentView('dashboard');
    } else {
      alert('Email немесе құпия сөз дұрыс емес!');
    }
  };

  const handleRegister = (userData: any) => {
    const existingUser = users.find(u => u.email === userData.email);
    if (existingUser) {
      alert('Бұл email-мен тіркелген пайдаланушы бар!');
      return;
    }

    const baseUser = {
      id: Date.now().toString(),
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      password: userData.password,
      phone: userData.phone,
      avatar: userData.avatar,
      createdAt: new Date().toISOString(),
    };

    let newUser: any;
    if (userData.role === 'student') {
      newUser = {
        ...baseUser,
        role: 'student',
        group: userData.group,
        course: userData.course,
        specialty: userData.specialty,
      };
    } else {
      newUser = {
        ...baseUser,
        role: 'teacher',
        subject: userData.subject,
        department: userData.department,
      };
    }

    setUsers([...users, newUser]);
    setCurrentUser(newUser);
    if (newUser.role === 'student') {
      setSelectedGroup(newUser.group);
    }
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('login');
    setIsMenuOpen(false);
    setSelectedGroup('');
  };

  const updateProfile = (updatedData: any) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, ...updatedData };
      setCurrentUser(updatedUser);
      setUsers(users.map(u => u.id === updatedUser.id ? updatedUser : u));
      if (updatedData.role === 'student' && 'group' in updatedData) {
        setSelectedGroup(updatedData.group);
      }
    }
  };

  const addGrade = (grade: Omit<Grade, 'id'>) => {
    const newGrade: Grade = {
      ...grade,
      id: Date.now().toString(),
    };
    setGrades([...grades, newGrade]);
  };

  const deleteGrade = (gradeId: string) => {
    setGrades(grades.filter(g => g.id !== gradeId));
  };

  const getStudentGrades = (studentId: string) => {
    return grades.filter(g => g.studentId === studentId);
  };

  const getGroupStudents = (group: string) => {
    return users.filter(u => u.role === 'student' && (u as Student).group === group) as Student[];
  };

  const renderContent = () => {
    if (!currentUser) {
      switch (currentView) {
        case 'login':
          return <LoginView onLogin={handleLogin} onRegisterClick={() => setCurrentView('register')} />;
        case 'register':
          return <RegisterView onRegister={handleRegister} onLoginClick={() => setCurrentView('login')} />;
        default:
          return <LoginView onLogin={handleLogin} onRegisterClick={() => setCurrentView('register')} />;
      }
    }

    if (currentUser.role === 'teacher') {
      switch (currentView) {
        case 'dashboard':
          return <TeacherDashboardView currentUser={currentUser as Teacher} />;
        case 'teacher-grades':
          return <TeacherGradesView 
            currentUser={currentUser as Teacher} 
            grades={grades}
            groups={groups}
            getGroupStudents={getGroupStudents}
            addGrade={addGrade}
            deleteGrade={deleteGrade}
          />;
        case 'students':
          return <StudentsListView 
            groups={groups}
            getGroupStudents={getGroupStudents}
          />;
        case 'schedule':
          return <ScheduleView selectedGroup={selectedGroup} onGroupChange={setSelectedGroup} />;
        case 'profile':
          return <ProfileView currentUser={currentUser} onUpdate={updateProfile} groups={groups} />;
        case 'news':
          return <NewsView />;
        default:
          return <TeacherDashboardView currentUser={currentUser as Teacher} />;
      }
    } else {
      switch (currentView) {
        case 'dashboard':
          return <StudentDashboardView currentUser={currentUser as Student} grades={getStudentGrades(currentUser.id)} selectedGroup={selectedGroup} />;
        case 'schedule':
          return <ScheduleView selectedGroup={selectedGroup} onGroupChange={setSelectedGroup} />;
        case 'grades':
          return <StudentGradesView grades={getStudentGrades(currentUser.id)} />;
        case 'profile':
          return <ProfileView currentUser={currentUser} onUpdate={updateProfile} groups={groups} />;
        case 'news':
          return <NewsView />;
        default:
          return <StudentDashboardView currentUser={currentUser as Student} grades={getStudentGrades(currentUser.id)} selectedGroup={selectedGroup} />;
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-blue-50">
      {currentUser && (
        <header className="fixed top-0 left-0 right-0 bg-gradient-to-r from-red-600 to-blue-600 shadow-lg z-50">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="bg-white/20 p-2 rounded-lg">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <span className="font-bold text-lg text-white">CollegeApp</span>
                <Badge className="ml-2 bg-white/20 text-white text-xs">
                  {currentUser.role === 'teacher' ? 'Мұғалім' : 'Студент'}
                </Badge>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white hover:bg-white/20"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </header>
      )}

      {isMenuOpen && currentUser && (
        <div className="fixed inset-0 bg-black/50 z-40" onClick={() => setIsMenuOpen(false)}>
          <div className="absolute right-0 top-14 w-72 bg-white shadow-2xl rounded-l-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-red-600 to-blue-600 p-4">
              <div className="flex items-center gap-3">
                <Avatar className="w-14 h-14 border-2 border-white">
                  <AvatarImage src={currentUser.avatar} />
                  <AvatarFallback className="bg-white text-red-600 font-bold">
                    {currentUser.firstName[0]}{currentUser.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-white">{currentUser.firstName} {currentUser.lastName}</p>
                  <p className="text-sm text-white/80">
                    {currentUser.role === 'teacher' 
                      ? (currentUser as Teacher).subject 
                      : (currentUser as Student).group}
                  </p>
                </div>
              </div>
            </div>
            <nav className="p-2">
              <NavItem icon={<Home className="text-red-500" />} label="Басты бет" onClick={() => { setCurrentView('dashboard'); setIsMenuOpen(false); }} />
              
              {currentUser.role === 'teacher' ? (
                <>
                  <NavItem icon={<Award className="text-blue-500" />} label="Бағалар қою" onClick={() => { setCurrentView('teacher-grades'); setIsMenuOpen(false); }} />
                  <NavItem icon={<Users className="text-red-500" />} label="Студенттер" onClick={() => { setCurrentView('students'); setIsMenuOpen(false); }} />
                </>
              ) : (
                <>
                  <NavItem icon={<Calendar className="text-blue-500" />} label="Сабақ кестесі" onClick={() => { setCurrentView('schedule'); setIsMenuOpen(false); }} />
                  <NavItem icon={<BookOpen className="text-red-500" />} label="Менің бағаларым" onClick={() => { setCurrentView('grades'); setIsMenuOpen(false); }} />
                </>
              )}
              
              <NavItem icon={<Bell className="text-blue-500" />} label="Жаңалықтар" onClick={() => { setCurrentView('news'); setIsMenuOpen(false); }} />
              <NavItem icon={<UserIcon className="text-red-500" />} label="Профиль" onClick={() => { setCurrentView('profile'); setIsMenuOpen(false); }} />
              
              <Separator className="my-2" />
              
              <NavItem icon={<LogOut className="text-red-500" />} label="Шығу" onClick={handleLogout} className="text-red-600 hover:bg-red-50" />
            </nav>
          </div>
        </div>
      )}

      <main className={`${currentUser ? 'pt-16' : ''} pb-20`}>
        {renderContent()}
      </main>

      {currentUser && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-2 z-50 shadow-lg">
          <div className="flex justify-around items-center">
            <BottomNavItem 
              icon={<Home className="w-5 h-5" />} 
              label="Басты" 
              isActive={currentView === 'dashboard'}
              onClick={() => setCurrentView('dashboard')}
            />
            
            {currentUser.role === 'teacher' ? (
              <>
                <BottomNavItem 
                  icon={<Award className="w-5 h-5" />} 
                  label="Бағалар" 
                  isActive={currentView === 'teacher-grades'}
                  onClick={() => setCurrentView('teacher-grades')}
                />
                <BottomNavItem 
                  icon={<Users className="w-5 h-5" />} 
                  label="Студенттер" 
                  isActive={currentView === 'students'}
                  onClick={() => setCurrentView('students')}
                />
              </>
            ) : (
              <>
                <BottomNavItem 
                  icon={<Calendar className="w-5 h-5" />} 
                  label="Кесте" 
                  isActive={currentView === 'schedule'}
                  onClick={() => setCurrentView('schedule')}
                />
                <BottomNavItem 
                  icon={<BookOpen className="w-5 h-5" />} 
                  label="Бағалар" 
                  isActive={currentView === 'grades'}
                  onClick={() => setCurrentView('grades')}
                />
              </>
            )}
            
            <BottomNavItem 
              icon={<UserIcon className="w-5 h-5" />} 
              label="Профиль" 
              isActive={currentView === 'profile'}
              onClick={() => setCurrentView('profile')}
            />
          </div>
        </nav>
      )}
    </div>
  );
}

// Navigation Components
function NavItem({ icon, label, onClick, className = '' }: { icon: React.ReactNode; label: string; onClick: () => void; className?: string }) {
  return (
    <button 
      onClick={onClick} 
      className={`flex items-center gap-3 w-full p-3 rounded-xl hover:bg-gradient-to-r hover:from-red-50 hover:to-blue-50 transition-all ${className}`}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </button>
  );
}

function BottomNavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode; label: string; isActive: boolean; onClick: () => void }) {
  return (
    <button 
      onClick={onClick} 
      className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${
        isActive 
          ? 'text-white bg-gradient-to-r from-red-500 to-blue-500 shadow-md' 
          : 'text-gray-500 hover:bg-gray-100'
      }`}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

// Login View with Role Selection
function LoginView({ onLogin, onRegisterClick }: { onLogin: (email: string, password: string) => void; onRegisterClick: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(email, password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-500 via-red-600 to-blue-600 p-4">
      <Card className="w-full max-w-md shadow-2xl border-0">
        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-red-500 to-blue-500 p-4 rounded-2xl shadow-lg">
              <GraduationCap className="w-16 h-16 text-white" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
            CollegeApp
          </CardTitle>
          <p className="text-gray-500 mt-2">Колледж студенттері мен мұғалімдері үшін</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-gray-700">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="email@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="border-gray-300 focus:border-red-500 focus:ring-red-500"
              />
            </div>
            <div>
              <Label htmlFor="password" className="text-gray-700">Құпия сөз</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                className="border-gray-300 focus:border-red-500 focus:ring-red-500"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-red-500 to-blue-500 hover:from-red-600 hover:to-blue-600 text-white font-semibold py-3 rounded-xl shadow-lg"
            >
              Кіру
            </Button>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-gray-500">Аккаунтыңыз жоқ па?</p>
            <Button 
              variant="link" 
              onClick={onRegisterClick}
              className="text-red-600 hover:text-blue-600 font-semibold"
            >
              Тіркелу
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Register View with Role Selection
function RegisterView({ onRegister, onLoginClick }: { onRegister: (data: any) => void; onLoginClick: () => void }) {
  const [role, setRole] = useState<UserRole>('student');
  const [formData, setFormData] = useState<any>({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    phone: '',
    group: '',
    course: 3,
    specialty: '',
    subject: '',
    department: '',
    role: 'student',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRegister({ ...formData, role });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-500 via-red-600 to-blue-600 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-auto shadow-2xl border-0">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
            Тіркелу
          </CardTitle>
          <p className="text-gray-500">Жаңа аккаунт жасау</p>
        </CardHeader>
        <CardContent>
          {/* Role Selection */}
          <div className="mb-6">
            <Label className="text-gray-700 mb-2 block">Кім ретінде тіркелесіз?</Label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  setRole('student');
                  setFormData({ ...formData, role: 'student' });
                }}
                className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                  role === 'student' 
                    ? 'border-red-500 bg-red-50' 
                    : 'border-gray-200 hover:border-red-200'
                }`}
              >
                <GraduationCap className={`w-8 h-8 ${role === 'student' ? 'text-red-500' : 'text-gray-400'}`} />
                <span className={`font-medium ${role === 'student' ? 'text-red-700' : 'text-gray-600'}`}>Студент</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setRole('teacher');
                  setFormData({ ...formData, role: 'teacher' });
                }}
                className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                  role === 'teacher' 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-blue-200'
                }`}
              >
                <Award className={`w-8 h-8 ${role === 'teacher' ? 'text-blue-500' : 'text-gray-400'}`} />
                <span className={`font-medium ${role === 'teacher' ? 'text-blue-700' : 'text-gray-600'}`}>Мұғалім</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Аты</Label>
                <Input 
                  id="firstName" 
                  value={formData.firstName}
                  onChange={e => setFormData({...formData, firstName: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="lastName">Тегі</Label>
                <Input 
                  id="lastName" 
                  value={formData.lastName}
                  onChange={e => setFormData({...formData, lastName: e.target.value})}
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email"
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="password">Құпия сөз</Label>
              <Input 
                id="password" 
                type="password"
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="phone">Телефон</Label>
              <Input 
                id="phone" 
                type="tel"
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
              />
            </div>

            {role === 'student' ? (
              <>
                <div>
                  <Label htmlFor="group">Топ</Label>
                  <Select 
                    value={formData.group} 
                    onValueChange={(value) => setFormData({...formData, group: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Топты таңдаңыз" />
                    </SelectTrigger>
                    <SelectContent>
                      {groups.map(group => (
                        <SelectItem key={group} value={group}>{group}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="course">Курс</Label>
                  <Input 
                    id="course" 
                    type="number"
                    min={1}
                    max={4}
                    value={formData.course}
                    onChange={e => setFormData({...formData, course: parseInt(e.target.value)})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="specialty">Мамандық</Label>
                  <Input 
                    id="specialty" 
                    placeholder="Мысалы: Ақпараттық жүйелер"
                    value={formData.specialty}
                    onChange={e => setFormData({...formData, specialty: e.target.value})}
                    required
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <Label htmlFor="subject">Оқытатын пән</Label>
                  <Select 
                    value={formData.subject} 
                    onValueChange={(value) => setFormData({...formData, subject: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Пәнді таңдаңыз" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[200px]">
                      {subjectsList.map(subject => (
                        <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="department">Кафедра</Label>
                  <Select 
                    value={formData.department} 
                    onValueChange={(value) => setFormData({...formData, department: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Кафедраны таңдаңыз" />
                    </SelectTrigger>
                    <SelectContent>
                      {departmentsList.map(dept => (
                        <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-red-500 to-blue-500 hover:from-red-600 hover:to-blue-600 text-white font-semibold py-3 rounded-xl"
            >
              Тіркелу
            </Button>
          </form>
          
          <div className="mt-4 text-center">
            <Button 
              variant="link" 
              onClick={onLoginClick}
              className="text-red-600 hover:text-blue-600"
            >
              Кіру бетіне оралу
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Student Dashboard
function StudentDashboardView({ currentUser, grades, selectedGroup }: { currentUser: Student; grades: Grade[]; selectedGroup: string }) {
  const today = new Date().toLocaleDateString('kk-KZ', { weekday: 'long', day: 'numeric', month: 'long' });
  const todayKazakh = getKazakhDayName(new Date().getDay());
  const todaySchedule = selectedGroup ? getScheduleByGroupAndDay(selectedGroup, todayKazakh) : [];
  
  const avgGrade = grades.length > 0 
    ? grades.reduce((acc, g) => acc + (g.score / g.maxScore) * 100, 0) / grades.length 
    : 0;

  return (
    <ScrollArea className="h-[calc(100vh-8rem)]">
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500">{today}</p>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
              Сәлем, {currentUser.firstName}!
            </h1>
          </div>
          <Button variant="ghost" size="icon" className="relative bg-gradient-to-r from-red-100 to-blue-100">
            <Bell className="w-6 h-6 text-red-600" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">3</span>
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="bg-green-500 p-2 rounded-lg">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-sm text-gray-600">Баға саны</span>
              </div>
              <p className="text-2xl font-bold text-green-700">{grades.length}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="bg-yellow-500 p-2 rounded-lg">
                  <Star className="w-5 h-5 text-white" />
                </div>
                <span className="text-sm text-gray-600">Орташа баға</span>
              </div>
              <p className="text-2xl font-bold text-yellow-700">{avgGrade.toFixed(1)}%</p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-0 shadow-lg overflow-hidden">
          <CardHeader className="pb-2 bg-gradient-to-r from-red-500 to-blue-500">
            <CardTitle className="text-lg flex items-center justify-between text-white">
              <span>Бүгінгі сабақтар</span>
              <Badge className="bg-white/20 text-white">{todaySchedule.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 p-4">
            {todaySchedule.length > 0 ? (
              todaySchedule.map(item => (
                <div key={item.id} className="flex items-center gap-3 p-3 bg-gradient-to-r from-red-50 to-blue-50 rounded-xl border border-red-100">
                  <div className="flex flex-col items-center min-w-[70px] bg-white rounded-lg p-2 shadow-sm">
                    <span className="text-sm font-bold text-red-600">{item.startTime}</span>
                    <span className="text-xs text-gray-400">{item.endTime}</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800">{item.subject}</p>
                    <p className="text-sm text-gray-500">{item.teacher} • {item.room}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 py-4">Бүгін сабақ жоқ</p>
            )}
          </CardContent>
        </Card>

        {grades.length > 0 && (
          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-gray-800">Соңғы бағалар</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {grades.slice(-3).map(grade => (
                <div key={grade.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-red-50 to-blue-50 rounded-xl">
                  <div>
                    <p className="font-semibold text-gray-800">{grade.subject}</p>
                    <p className="text-sm text-gray-500">{grade.teacherName}</p>
                  </div>
                  <Badge className={`${
                    grade.score >= 90 ? 'bg-green-100 text-green-700' :
                    grade.score >= 70 ? 'bg-blue-100 text-blue-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {grade.score}/{grade.maxScore}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </ScrollArea>
  );
}

// Teacher Dashboard
function TeacherDashboardView({ currentUser }: { currentUser: Teacher }) {
  const today = new Date().toLocaleDateString('kk-KZ', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <ScrollArea className="h-[calc(100vh-8rem)]">
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500">{today}</p>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
              Сәлем, {currentUser.firstName}!
            </h1>
          </div>
          <Button variant="ghost" size="icon" className="relative bg-gradient-to-r from-red-100 to-blue-100">
            <Bell className="w-6 h-6 text-red-600" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">2</span>
          </Button>
        </div>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-500 p-3 rounded-xl">
                <Award className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Оқытатын пән</p>
                <p className="text-lg font-bold text-blue-700">{currentUser.subject}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-4">
          <Card 
            className="border-0 shadow-lg bg-gradient-to-br from-red-50 to-red-100 cursor-pointer hover:shadow-xl transition-shadow"
            onClick={() => {}}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="bg-red-500 p-2 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
              </div>
              <p className="text-lg font-bold text-red-700">Баға қою</p>
              <p className="text-sm text-gray-500">Студенттерге баға қою</p>
            </CardContent>
          </Card>
          
          <Card 
            className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100 cursor-pointer hover:shadow-xl transition-shadow"
            onClick={() => {}}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="bg-purple-500 p-2 rounded-lg">
                  <Users className="w-5 h-5 text-white" />
                </div>
              </div>
              <p className="text-lg font-bold text-purple-700">Студенттер</p>
              <p className="text-sm text-gray-500">Топтарды қарау</p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-2 bg-gradient-to-r from-red-500 to-blue-500">
            <CardTitle className="text-lg text-white">Жылдам әрекеттер</CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-3">
            <Button 
              className="w-full bg-gradient-to-r from-red-500 to-red-600 text-white"
              onClick={() => {}}
            >
              <Plus className="w-4 h-4 mr-2" />
              Жаңа баға қою
            </Button>
            <Button 
              variant="outline" 
              className="w-full border-blue-200 text-blue-600 hover:bg-blue-50"
              onClick={() => {}}
            >
              <Search className="w-4 h-4 mr-2" />
              Студент іздеу
            </Button>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  );
}

// Teacher Grades View
function TeacherGradesView({ 
  currentUser, 
  grades, 
  groups, 
  getGroupStudents, 
  addGrade, 
  deleteGrade 
}: { 
  currentUser: Teacher;
  grades: Grade[];
  groups: string[];
  getGroupStudents: (group: string) => Student[];
  addGrade: (grade: Omit<Grade, 'id'>) => void;
  deleteGrade: (gradeId: string) => void;
}) {
  const [selectedGroup, setSelectedGroup] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newGrade, setNewGrade] = useState({
    score: 0,
    maxScore: 100,
    type: 'test' as const,
    comment: '',
  });

  const teacherGrades = grades.filter(g => g.teacherId === currentUser.id);
  const groupStudents = selectedGroup ? getGroupStudents(selectedGroup) : [];

  const handleAddGrade = () => {
    if (!selectedStudent) return;
    
    addGrade({
      studentId: selectedStudent.id,
      studentName: `${selectedStudent.firstName} ${selectedStudent.lastName}`,
      studentGroup: selectedStudent.group,
      subject: currentUser.subject,
      teacherId: currentUser.id,
      teacherName: `${currentUser.firstName} ${currentUser.lastName}`,
      score: newGrade.score,
      maxScore: newGrade.maxScore,
      type: newGrade.type,
      date: new Date().toISOString().split('T')[0],
      semester: 'Қысқы семестр 2026',
      comment: newGrade.comment,
    });
    
    setShowAddDialog(false);
    setNewGrade({ score: 0, maxScore: 100, type: 'test', comment: '' });
  };

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
        Бағалар қою
      </h1>

      {/* Group Selection */}
      <Card className="border-0 shadow-md">
        <CardContent className="p-4">
          <Label className="text-gray-700 mb-2 block">Топты таңдаңыз</Label>
          <Select value={selectedGroup} onValueChange={setSelectedGroup}>
            <SelectTrigger className="border-red-200">
              <SelectValue placeholder="Топты таңдаңыз" />
            </SelectTrigger>
            <SelectContent>
              {groups.map(group => (
                <SelectItem key={group} value={group}>{group}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Students List */}
      {selectedGroup && (
        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-gray-800">{selectedGroup} - Студенттер</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {groupStudents.map(student => {
              const studentGrades = grades.filter(g => g.studentId === student.id && g.teacherId === currentUser.id);
              const avgScore = studentGrades.length > 0
                ? studentGrades.reduce((acc, g) => acc + (g.score / g.maxScore) * 100, 0) / studentGrades.length
                : 0;

              return (
                <div key={student.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-red-50 to-blue-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-gradient-to-r from-red-500 to-blue-500 text-white text-sm">
                        {student.firstName[0]}{student.lastName[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-gray-800">{student.firstName} {student.lastName}</p>
                      <p className="text-sm text-gray-500">{studentGrades.length} баға</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {avgScore > 0 && (
                      <Badge className={`${
                        avgScore >= 90 ? 'bg-green-100 text-green-700' :
                        avgScore >= 70 ? 'bg-blue-100 text-blue-700' :
                        'bg-yellow-100 text-yellow-700'
                      }`}>
                        {avgScore.toFixed(0)}%
                      </Badge>
                    )}
                    <Dialog open={showAddDialog && selectedStudent?.id === student.id} onOpenChange={(open) => {
                      setShowAddDialog(open);
                      if (open) setSelectedStudent(student);
                    }}>
                      <DialogTrigger asChild>
                        <Button size="sm" className="bg-gradient-to-r from-red-500 to-blue-500 text-white">
                          <Plus className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Баға қою - {student.firstName} {student.lastName}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 pt-4">
                          <div>
                            <Label>Баға түрі</Label>
                            <Select 
                              value={newGrade.type} 
                              onValueChange={(v: any) => setNewGrade({...newGrade, type: v})}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="exam">Емтихан</SelectItem>
                                <SelectItem value="test">Тест</SelectItem>
                                <SelectItem value="homework">Үй жұмысы</SelectItem>
                                <SelectItem value="project">Жоба</SelectItem>
                                <SelectItem value="quiz">Жұмыс</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Баға</Label>
                              <Input 
                                type="number"
                                min={0}
                                max={newGrade.maxScore}
                                value={newGrade.score}
                                onChange={e => setNewGrade({...newGrade, score: parseInt(e.target.value) || 0})}
                              />
                            </div>
                            <div>
                              <Label>Максималды</Label>
                              <Input 
                                type="number"
                                min={1}
                                value={newGrade.maxScore}
                                onChange={e => setNewGrade({...newGrade, maxScore: parseInt(e.target.value) || 100})}
                              />
                            </div>
                          </div>
                          <div>
                            <Label>Комментарий (міндетті емес)</Label>
                            <Input 
                              value={newGrade.comment}
                              onChange={e => setNewGrade({...newGrade, comment: e.target.value})}
                              placeholder="Комментарий"
                            />
                          </div>
                          <Button 
                            className="w-full bg-gradient-to-r from-red-500 to-blue-500 text-white"
                            onClick={handleAddGrade}
                          >
                            <Save className="w-4 h-4 mr-2" />
                            Сақтау
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              );
            })}
            {groupStudents.length === 0 && (
              <p className="text-center text-gray-500 py-4">Бұл топта студенттер жоқ</p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Recent Grades */}
      {teacherGrades.length > 0 && (
        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-gray-800">Соңғы қойылған бағалар</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {teacherGrades.slice(-5).reverse().map(grade => (
              <div key={grade.id} className="flex items-center justify-between p-3 bg-white rounded-xl border border-gray-100">
                <div>
                  <p className="font-semibold text-gray-800">{grade.studentName}</p>
                  <p className="text-sm text-gray-500">{grade.studentGroup} • {grade.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`${
                    grade.score >= 90 ? 'bg-green-100 text-green-700' :
                    grade.score >= 70 ? 'bg-blue-100 text-blue-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {grade.score}/{grade.maxScore}
                  </Badge>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => deleteGrade(grade.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Students List View for Teachers
function StudentsListView({ 
  groups, 
  getGroupStudents 
}: { 
  groups: string[];
  getGroupStudents: (group: string) => Student[];
}) {
  const [selectedGroup, setSelectedGroup] = useState('');
  const students = selectedGroup ? getGroupStudents(selectedGroup) : [];

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
        Студенттер тізімі
      </h1>

      <Card className="border-0 shadow-md">
        <CardContent className="p-4">
          <Label className="text-gray-700 mb-2 block">Топты таңдаңыз</Label>
          <Select value={selectedGroup} onValueChange={setSelectedGroup}>
            <SelectTrigger className="border-red-200">
              <SelectValue placeholder="Топты таңдаңыз" />
            </SelectTrigger>
            <SelectContent>
              {groups.map(group => (
                <SelectItem key={group} value={group}>{group}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedGroup && (
        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-gray-800">
              {selectedGroup} • {students.length} студент
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {students.map((student, index) => (
              <div key={student.id} className="flex items-center gap-3 p-3 bg-gradient-to-r from-red-50 to-blue-50 rounded-xl">
                <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {index + 1}
                </div>
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-white text-red-600">
                    {student.firstName[0]}{student.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-semibold text-gray-800">{student.firstName} {student.lastName}</p>
                  <p className="text-sm text-gray-500">{student.email}</p>
                </div>
                <Badge variant="outline">{student.course}-курс</Badge>
              </div>
            ))}
            {students.length === 0 && (
              <p className="text-center text-gray-500 py-4">Бұл топта студенттер жоқ</p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Student Grades View
function StudentGradesView({ grades }: { grades: Grade[] }) {
  const avgGrade = grades.length > 0 
    ? grades.reduce((acc, g) => acc + (g.score / g.maxScore) * 100, 0) / grades.length 
    : 0;

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
        Менің бағаларым
      </h1>

      <Card className="border-0 shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-yellow-500 p-3 rounded-xl">
                <Star className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Орташа баға</p>
                <p className="text-2xl font-bold text-yellow-700">{avgGrade.toFixed(1)}%</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Баға саны</p>
              <p className="text-xl font-bold text-gray-700">{grades.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {grades.length > 0 ? (
          grades.map(grade => (
            <Card key={grade.id} className="border-0 shadow-md">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-800">{grade.subject}</h3>
                    <p className="text-sm text-gray-500">{grade.teacherName}</p>
                    <p className="text-xs text-gray-400">{grade.date}</p>
                  </div>
                  <div className="text-right">
                    <span className={`text-2xl font-bold ${
                      grade.score >= 90 ? 'text-green-500' : 
                      grade.score >= 70 ? 'text-blue-500' : 'text-yellow-500'
                    }`}>
                      {grade.score}
                    </span>
                    <span className="text-gray-400">/{grade.maxScore}</span>
                  </div>
                </div>
                {grade.comment && (
                  <p className="mt-2 text-sm text-gray-600 bg-gray-50 p-2 rounded-lg">
                    {grade.comment}
                  </p>
                )}
              </CardContent>
            </Card>
          ))
        ) : (
          <Card className="border-0 shadow-md">
            <CardContent className="p-8 text-center">
              <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Әлі бағалар жоқ</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

// Schedule View
function ScheduleView({ selectedGroup, onGroupChange }: { selectedGroup: string; onGroupChange: (group: string) => void }) {
  const days = ['Дүйсенбі', 'Сейсенбі', 'Сәрсенбі', 'Бейсенбі', 'Жұма'];
  const [selectedDay, setSelectedDay] = useState(days[0]);

  const daySchedule = selectedGroup ? getScheduleByGroupAndDay(selectedGroup, selectedDay) : [];

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
        Сабақ кестесі
      </h1>
      
      <Card className="border-0 shadow-md">
        <CardContent className="p-4">
          <Label className="text-gray-700 mb-2 block">Топты таңдаңыз</Label>
          <Select value={selectedGroup} onValueChange={onGroupChange}>
            <SelectTrigger className="border-red-200">
              <SelectValue placeholder="Топты таңдаңыз" />
            </SelectTrigger>
            <SelectContent className="max-h-[300px]">
              {groups.map(group => (
                <SelectItem key={group} value={group}>{group}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-2 pb-2">
          {days.map(day => (
            <Button
              key={day}
              variant={selectedDay === day ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedDay(day)}
              className={selectedDay === day 
                ? 'bg-gradient-to-r from-red-500 to-blue-500 text-white border-0' 
                : 'border-red-200 text-gray-700 hover:bg-red-50'
              }
            >
              {day}
            </Button>
          ))}
        </div>
      </ScrollArea>

      <div className="space-y-3">
        {!selectedGroup && (
          <Card className="border-0 shadow-md">
            <CardContent className="p-8 text-center">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Кестені көру үшін топты таңдаңыз</p>
            </CardContent>
          </Card>
        )}
        
        {selectedGroup && daySchedule.map(item => (
          <Card key={item.id} className="border-0 shadow-md overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div className="flex flex-col items-center min-w-[80px] bg-gradient-to-br from-red-500 to-blue-500 rounded-xl p-3 text-white">
                  <Clock className="w-4 h-4 mb-1" />
                  <span className="text-sm font-bold">{item.startTime}</span>
                  <span className="text-xs opacity-80">{item.endTime}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg text-gray-800">{item.subject}</h3>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <UserIcon className="w-4 h-4 text-red-500" />
                      {item.teacher}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4 text-blue-500" />
                      {item.room}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {selectedGroup && daySchedule.length === 0 && (
          <Card className="border-0 shadow-md">
            <CardContent className="p-8 text-center">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Бұл күні сабақ жоқ</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

// Profile View
function ProfileView({ currentUser, onUpdate, groups }: { currentUser: User | null; onUpdate: (data: any) => void; groups: string[] }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(currentUser || {} as any);

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  if (!currentUser) return null;

  const isTeacher = currentUser.role === 'teacher';

  return (
    <ScrollArea className="h-[calc(100vh-8rem)]">
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
          Профиль
        </h1>
        
        <Card className="border-0 shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-red-500 to-blue-500 p-6">
            <div className="flex flex-col items-center">
              <Avatar className="w-24 h-24 mb-4 border-4 border-white">
                <AvatarImage src={currentUser.avatar} />
                <AvatarFallback className="text-2xl bg-white text-red-600 font-bold">
                  {currentUser.firstName[0]}{currentUser.lastName[0]}
                </AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-bold text-white">{currentUser.firstName} {currentUser.lastName}</h2>
              <Badge className="mt-2 bg-white/20 text-white">
                {isTeacher ? 'Мұғалім' : 'Студент'}
              </Badge>
            </div>
          </div>

          <CardContent className="p-6">
            {isEditing ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Аты</Label>
                    <Input 
                      value={formData.firstName}
                      onChange={e => setFormData({...formData, firstName: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Тегі</Label>
                    <Input 
                      value={formData.lastName}
                      onChange={e => setFormData({...formData, lastName: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <Label>Email</Label>
                  <Input 
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Телефон</Label>
                  <Input 
                    type="tel"
                    value={formData.phone || ''}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
                
                {isTeacher ? (
                  <>
                    <div>
                      <Label>Оқытатын пән</Label>
                      <Input 
                        value={formData.subject}
                        onChange={e => setFormData({...formData, subject: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label>Кафедра</Label>
                      <Input 
                        value={formData.department}
                        onChange={e => setFormData({...formData, department: e.target.value})}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <Label>Топ</Label>
                      <Select 
                        value={formData.group} 
                        onValueChange={(value) => setFormData({...formData, group: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Топты таңдаңыз" />
                        </SelectTrigger>
                        <SelectContent>
                          {groups.map(group => (
                            <SelectItem key={group} value={group}>{group}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Мамандық</Label>
                      <Input 
                        value={formData.specialty}
                        onChange={e => setFormData({...formData, specialty: e.target.value})}
                      />
                    </div>
                  </>
                )}
                
                <div className="flex gap-2">
                  <Button 
                    onClick={handleSave} 
                    className="flex-1 bg-gradient-to-r from-red-500 to-blue-500 text-white"
                  >
                    Сақтау
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)}>Болдырмау</Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-500">Email</span>
                  <span className="font-medium text-gray-800">{currentUser.email}</span>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-500">Телефон</span>
                  <span className="font-medium text-gray-800">{currentUser.phone || 'Көрсетілмеген'}</span>
                </div>
                
                {isTeacher ? (
                  <>
                    <div className="flex items-center justify-between py-3 border-b border-gray-100">
                      <span className="text-gray-500">Оқытатын пән</span>
                      <span className="font-medium text-gray-800">{(currentUser as Teacher).subject}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-gray-100">
                      <span className="text-gray-500">Кафедра</span>
                      <span className="font-medium text-gray-800">{(currentUser as Teacher).department}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center justify-between py-3 border-b border-gray-100">
                      <span className="text-gray-500">Топ</span>
                      <span className="font-medium text-gray-800">{(currentUser as Student).group}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-gray-100">
                      <span className="text-gray-500">Курс</span>
                      <span className="font-medium text-gray-800">{(currentUser as Student).course}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-gray-100">
                      <span className="text-gray-500">Мамандық</span>
                      <span className="font-medium text-gray-800">{(currentUser as Student).specialty}</span>
                    </div>
                  </>
                )}
                
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-500">Тіркелген күні</span>
                  <span className="font-medium text-gray-800">{new Date(currentUser.createdAt).toLocaleDateString('kk-KZ')}</span>
                </div>
                
                <Button 
                  onClick={() => setIsEditing(true)} 
                  className="w-full bg-gradient-to-r from-red-500 to-blue-500 text-white"
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  Профильді өңдеу
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  );
}

// News View
function NewsView() {
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent">
        Жаңалықтар
      </h1>
      
      <div className="space-y-4">
        {mockNews.map(news => (
          <Card key={news.id} className="border-0 shadow-lg overflow-hidden">
            <div className={`h-2 ${
              news.category === 'urgent' ? 'bg-red-500' :
              news.category === 'academic' ? 'bg-blue-500' :
              news.category === 'event' ? 'bg-purple-500' :
              'bg-gray-500'
            }`} />
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Badge className={`
                  ${news.category === 'urgent' ? 'bg-red-500 text-white' : ''}
                  ${news.category === 'academic' ? 'bg-blue-500 text-white' : ''}
                  ${news.category === 'event' ? 'bg-purple-500 text-white' : ''}
                  ${news.category === 'general' ? 'bg-gray-500 text-white' : ''}
                `}>
                  {news.category === 'academic' ? 'Оқу' : news.category === 'event' ? 'Іс-шара' : news.category === 'urgent' ? 'Маңызды' : 'Жалпы'}
                </Badge>
                <span className="text-xs text-gray-400">{news.date}</span>
              </div>
              <h3 className="font-bold text-lg text-gray-800 mb-2">{news.title}</h3>
              <p className="text-gray-600 text-sm mb-3">{news.content}</p>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Users className="w-4 h-4 text-red-500" />
                <span>{news.author}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function getKazakhDayName(dayIndex: number): string {
  const days = ['Жексенбі', 'Дүйсенбі', 'Сейсенбі', 'Сәрсенбі', 'Бейсенбі', 'Жұма', 'Сенбі'];
  return days[dayIndex];
}

export default App;
